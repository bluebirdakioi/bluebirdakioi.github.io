---
layout: post
title: 保熟的链接
subtitle: 
categories: 资源
tags: 白嫖 实用
---
[洛谷 Meterial 美化插件 Archived](https://www.luogu.com.cn/blog/YunQian/stylishstylus-wo-di-liu-lan-qi-wo-zuo-zhu# )


[vocaloid](http://vocakey.info/)


[看板娘](https://paugram.com/coding/add-poster-girl-with-plugin.html)


[Markdown在线编辑器](https://www.zybuluo.com/mdeditor)


[Vocaloid论坛](http://bbs.ivocaloid.com)

[extend-luogu](https://exlg.cc)


