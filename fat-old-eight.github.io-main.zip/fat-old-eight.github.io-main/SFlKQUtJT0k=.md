![](https://cdn.jsdelivr.net/gh/fat-old-eight/fat-old-eight.github.io@main/assets/images/favicon.png)
