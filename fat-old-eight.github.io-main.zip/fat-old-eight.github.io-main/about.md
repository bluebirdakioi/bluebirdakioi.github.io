---
layout: about
title: 关于
---

## 关于

**左下角看板娘正在修复中**

在经过几天的努力后，我与同学（自信点，把我去掉）终于将我的博客搭建好了~~现在越来越会抄代码了~~。现在还在借鉴他人的博客主题。

后面的《关于》就懒得写了，咕咕咕……；

下面是友链：


|头像|name|备注|
|:--|:--|:--|
|[![EarthMessenger](https://avatars.githubusercontent.com/u/49364506?v=4&s=100)](earthmessenger.github.io)|[EarthMessenger](earthmessenger.github.io)|就是他改了亿些小 bug|
|[![云游君](https://avatars.githubusercontent.com/u/25154432?v=4&s=100)](https://www.yunyoujun.cn)                  |[云游君](https://www.yunyoujun.cn)                  |~~单向友链不违法吧~~%%%%|
|[![云浅知处](https://yunqian-qwq.github.io/images/avatar.png)](https://yunqian-qwq.github.io/)                    |[云浅知处](https://yunqian-qwq.github.io/)          |单向友链一定不违法|   
|[<img src="https://cdn.jsdelivr.net/gh/fat-old-eight/fat-old-eight.github.io@main/assets/pic/favicon.ico" width=100xp>](https://zxt688.top/)|[Norman](https://zxt688.top/)|《论单向友联的合法性》|
|[![小小小朋友](https://file.lijiaan.top/img/20201121002046.png)](https://lijiaan.top/)|[小小小朋友](https://lijiaan.top/)|我找到一个洛厨|
|[<img src="https://blog.pai233.top/img/avatar.jpg" width=100xp>](https://blog.pai233.top)|[pai233](https://blog.pai233.top)|Phigros|

~~我已经把单向友链玩明白了~~

本博客文章除特殊说明外，均使用CC BY-SA 4.0 和 SATA 协议，附加条款亦可能应用。


